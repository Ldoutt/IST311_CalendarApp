/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycalendar;

/**
 *
 * @author zifengxia
 */
public class MyCalendar {

        public static void main(String[] args) {
        // TODO code application logic here
        LoginCntl theLoginCntl=new LoginCntl();
          SearchModel model = new SearchModel();
        SearchView view = new SearchView(model);
        SearchController controller = new SearchController(model, view);
    
    
    view.setVisible(true);
    
    }
    
}