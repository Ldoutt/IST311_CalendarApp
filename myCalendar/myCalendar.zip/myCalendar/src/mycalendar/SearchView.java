package mycalendar;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


// @author Lauren

public class SearchView extends JFrame {
    
  
        private JTextField userInput = new JTextField();
        private JButton searchButton = new JButton("Search");
        private JLabel searchLabel = new JLabel("Results:");
        private JTextField results = new JTextField();
        private SearchModel model;
        
        SearchView(SearchModel model){
            this.model = model;
            
            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(2,2));
            panel.add(userInput);
            panel.add(searchButton);
            panel.add(searchLabel);
            panel.add(results);
       
            this.setContentPane(panel);
            this.pack();
            this.setTitle("Search");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
 String getInputFromUser(){
     return userInput.getText();
 }
 
 void addSearchButtonListener(ActionListener AL){
     searchButton.addActionListener(AL);
 }

 public void setResults(String resultfromSearch){
    results.setText(resultfromSearch);
 }

}
