package mycalendar;


//@author Lauren

import java.awt.event.*;
 
public class SearchController {
    private SearchModel model;
    private SearchView view;
    
    SearchController(SearchModel model, SearchView view){
        this.model = model;
        this.view = view;
        
        class ButtonListener implements ActionListener{
           public void actionPerformed(ActionEvent event)
           {
             view.setResults(model.getsearchResults(view.getInputFromUser()));  
           }
        }
       view.addSearchButtonListener(new ButtonListener());
      
    }
    
}