package mycalendar;

// @author Lauren

public class SearchModel {

    String [] practiceArray = {"Joe", "Lily", "Bob", "Mary", "Ryan"};
    String results= "";
    
    SearchModel(){
     
    }
    
    
    
    
    public String getsearchResults(String userInput) {
       for(int i=0; i<5; i++){
          if(userInput.equalsIgnoreCase(practiceArray[i])){
              results= practiceArray[i];
              break;
          }
          else{
              return "no match";
          }
          
       }
        return results;
    }
    
    }